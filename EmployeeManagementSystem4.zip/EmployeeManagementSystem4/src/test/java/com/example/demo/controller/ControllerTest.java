package com.example.demo.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.morningstar.demo.controller.EmployeeController;
import com.morningstar.demo.entity.Employee;
import com.morningstar.demo.service.EmployeeServiceImp;


@SpringBootTest(classes =ControllerTest.class )
class ControllerTest {

	@Mock
	EmployeeServiceImp employeeServiceImp;
	
	@InjectMocks
	EmployeeController employeeController;
	
	public List<Employee>emps;
	@Test
	@Order(1)
	public void test_getEmployee() {
		emps=new ArrayList<>();
		emps.add(new Employee(1,"pritam","gunjawate",23,39000.00,"Employee","pritam@gmail.com","pritam@123",null));
		emps.add(new Employee(2,"rahul","patil",25,39000.00,"Employee","rahul@gmail.com","rahul@123",null));
		emps.add(new Employee(3,"prathmesh","shinde",23,39000.00,"Employee","prathmesh@gmail.com","prathmesh@123",null));
		
		when(employeeServiceImp.findAll()).thenReturn(emps);
		
		ResponseEntity<List<Employee>> result=employeeController.displayAllEmployee();
		 
		Assertions.assertEquals(HttpStatus.OK, result.getStatusCode());
		Assertions.assertEquals(3,result.getBody().size());
		
	
	}

}