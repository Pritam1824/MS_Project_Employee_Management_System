package com.morningstar.demo.DTO;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

public class EmployeeDTO {
		
	public EmployeeDTO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public EmployeeDTO(int empId, @NotBlank(message = "Enter First name") String empFname,
			@NotBlank(message = "Enter Last name") String empLname, @Min(21) @Max(60) int empAge, double empSalary,
			@NotBlank(message = "Enter role") String empRole, @Email(message = "Enter valid email") String email,
			@NotBlank(message = "Enter password") String password, int departmentId) {
		super();
		this.empId = empId;
		this.empFname = empFname;
		this.empLname = empLname;
		this.empAge = empAge;
		this.empSalary = empSalary;
		this.empRole = empRole;
		this.email = email;
		this.password = password;
		this.departmentId = departmentId;
	}

	private int empId;
	
	@NotBlank(message="Enter First name")
	private String empFname;
	
	@NotBlank(message="Enter Last name")
	private String empLname;
	
	@Min(21)
	@Max(60)
	private int empAge;
	
	private double empSalary;
	
	@NotBlank(message="Enter role")
	private String empRole;
	
	@Email(message="Enter valid email")
	private String email;
	
	@NotBlank(message="Enter password")
	private String password;
	
	private int departmentId;

	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getEmpFname() {
		return empFname;
	}


	public void setEmpFname(String empFname) {
		this.empFname = empFname;
	}


	public String getEmpLname() {
		return empLname;
	}


	public void setEmpLname(String empLname) {
		this.empLname = empLname;
	}


	public int getEmpAge() {
		return empAge;
	}


	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}


	public double getEmpSalary() {
		return empSalary;
	}


	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}


	public String getEmpRole() {
		return empRole;
	}


	public void setEmpRole(String empRole) {
		this.empRole = empRole;
	}


	public int getDepartmentId() {
		return departmentId;
	}


	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	
}
