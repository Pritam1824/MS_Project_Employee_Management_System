package com.morningstar.demo.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.morningstar.demo.DTO.EmployeeDTO;
import com.morningstar.demo.controller.EmployeeController;
import com.morningstar.demo.entity.Department;
import com.morningstar.demo.entity.Employee;
import com.morningstar.demo.exception.EmployeeNotFoundException;
import com.morningstar.demo.exception.InvalidCredentialsException;
import com.morningstar.demo.repository.DepartmentRepository;
import com.morningstar.demo.repository.EmployeeRepository;

@Service
public class EmployeeServiceImp implements EmployeeService {
	private static Logger logger = LoggerFactory.getLogger(EmployeeController.class);

	@Autowired
	EmployeeRepository employeeRepository;
	@Autowired
	DepartmentRepository DepartmentRepository;

	@Override
	public Employee addEmployee(EmployeeDTO employeeDTO) {
		Employee employee = new Employee();
		employee.setEmpFname(employeeDTO.getEmpFname());
		employee.setEmpLname(employeeDTO.getEmpLname());
		employee.setEmpAge(employeeDTO.getEmpAge());
		employee.setEmpSalary(employeeDTO.getEmpSalary());
		employee.setEmpRole(employeeDTO.getEmpRole());
		employee.setEmail(employeeDTO.getEmail());
		employee.setPassword(employeeDTO.getPassword());
		Department department = DepartmentRepository.findById(employeeDTO.getDepartmentId()).get();
		employee.setDepartment(department);
		logger.info("Employee Added....!");
			return employeeRepository.save(employee);
			

	}
	
	@Override
	public List<Employee> findAll() {
		logger.info("All Employees fetched...!");
		return employeeRepository.findAll();

	}


	@Override
	public void updateEmployee(Employee employee, int id) throws EmployeeNotFoundException {

		String eFname = employee.getEmpFname();
		String eLname = employee.getEmpLname();
		int eAge = employee.getEmpAge();
		double eSalary = employee.getEmpSalary();
		String eRole = employee.getEmpRole();
		String  eEmail=employee.getEmail();
		String ePassword=employee.getPassword();
		Department eDept = employee.getDepartment();
		
		Optional<Employee> e = employeeRepository.findById(id);
		Employee empUpdate;
		if (e.isPresent()) {
			empUpdate = e.get();
			if (eFname != null) {
				empUpdate.setEmpFname(eFname);
			}
			if (eLname != null) {
				empUpdate.setEmpLname(eLname);
			}
			if (eAge != 0) {
				empUpdate.setEmpAge(eAge);
			}
			if (eSalary != 0.0) {
				empUpdate.setEmpSalary(eSalary);
			}
			if (eRole != null) {
				empUpdate.setEmpRole(eRole);
			}
			if (eDept != null) {
				empUpdate.setDepartment(eDept);
			}
			if (eEmail != null) {
				empUpdate.setEmail(eEmail);
			}
			if (ePassword != null) {
				empUpdate.setPassword(ePassword);
			}
			
			employeeRepository.save(empUpdate);
			logger.info(" Employee Updated...!");

		} else {
			throw new EmployeeNotFoundException("Employee Not Found");
		}
		
	}

	@Override
	public Employee displayEmployee(int id)throws EmployeeNotFoundException {
		Employee employee;
	        if (employeeRepository.findById(id).isEmpty()) {
	            throw new EmployeeNotFoundException();
	        } else {
	        	employee = employeeRepository.findById(id).get();
	    		logger.info("Single Employee fetched...!");

	        }
	        return employee;
	}

	
	@Override
	public String deleteEmployeeById(int id) throws EmployeeNotFoundException {

		 if (employeeRepository.findById(id).isEmpty()) {
	            throw new EmployeeNotFoundException();
	        } else {
	        	employeeRepository.deleteById(id);
	    		logger.info("employee deleted...!");

	        	return "Employee Deleted...!";
	        }
	}

	@Override
	public String getEmployee(String email, String password) {
		
		Employee emp = employeeRepository.getEmployee(email,password);
		if(emp==null) {
			throw new InvalidCredentialsException();
		}else {
			logger.info(emp.getEmpFname()+" "+emp.getEmpLname()+" logged in...! ");
		return "Successfully Logged in...!";
		}
	}
}
