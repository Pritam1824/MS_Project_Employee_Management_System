package com.morningstar.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeMgmtSystem2Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeMgmtSystem2Application.class, args);
	}

}
