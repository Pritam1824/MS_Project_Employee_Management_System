package com.morningstar.demo.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.morningstar.demo.entity.Department;
import com.morningstar.demo.entity.Employee;
import com.morningstar.demo.exception.DepartmentNotFoundException;
import com.morningstar.demo.service.DepartmentService;

@RestController
public class DepartmentController {

	@Autowired
	private DepartmentService departmentService;
	
	//Add department
	@PostMapping("/department")
	public ResponseEntity<String> displayDepartments(@RequestBody Department department){
		String status = departmentService.addDepartment(department);
		return new ResponseEntity<String>("Department added Successfully...!",HttpStatus.OK);
		
	}
	
	@GetMapping("/department/{deptId}")
	public ResponseEntity<List<Employee>> displayEmployeesByDepartmentId(@PathVariable("deptId") int deptId){
		//String status = departmentService.getEmployee(deptId);
		return new ResponseEntity<List<Employee>>(departmentService.getEmployeeByDeptId(deptId),HttpStatus.OK);
		
	}
	
	//view all departments
	@GetMapping("/department")
	public ResponseEntity<List<Department>> displayDepartments() {
	
		List<Department> list = departmentService.findAll();
		return new ResponseEntity<List<Department>>(list,HttpStatus.OK);
	}
	
	//view single department
	@GetMapping("/department/{id}")
	public ResponseEntity<Department> getDepartment(@PathVariable("id") int id)throws DepartmentNotFoundException{
	
		return new ResponseEntity<Department>(departmentService.getDepartment(id),HttpStatus.OK);
	}
}
