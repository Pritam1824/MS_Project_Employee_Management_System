package com.morningstar.demo.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;

@Entity
public class Employee {

	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int empId, String empFname, String empLname, int empAge, double empSalary, String empRole,
			String email, String password, Department department) {
		super();
		this.empId = empId;
		this.empFname = empFname;
		this.empLname = empLname;
		this.empAge = empAge;
		this.empSalary = empSalary;
		this.empRole = empRole;
		this.email = email;
		this.password = password;
		this.department = department;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int empId;
	
	
	@Column(name="First_name",length = 30)
	private String empFname;
	
	@Column(name="last_name",length = 30)
	private String empLname;
	
	@Column(name="Age")
	private int empAge;
	
	@Column(name="Salary")
	private double empSalary;
	
	@Column(name="Role",length = 30)
	private String empRole;
	
	@Column(name="email")
	private String email;
	
	@Column(name="password",nullable = false)
	private String password;
	
	@ManyToOne(cascade = CascadeType.PERSIST)
	private Department department;
	
	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpFname() {
		return empFname;
	}

	public void setEmpFname(String empFname) {
		this.empFname = empFname;
	}

	public String getEmpLname() {
		return empLname;
	}

	public void setEmpLname(String empLname) {
		this.empLname = empLname;
	}

	public int getEmpAge() {
		return empAge;
	}

	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	public String getEmpRole() {
		return empRole;
	}

	public void setEmpRole(String empRole) {
		this.empRole = empRole;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empFname=" + empFname + ", empLname=" + empLname + ", empAge=" + empAge
				+ ", empSalary=" + empSalary + ", empRole=" + empRole + ", email=" + email + ", password=" + password
				+ ", department=" + department + "]";
	}

	
	
}
