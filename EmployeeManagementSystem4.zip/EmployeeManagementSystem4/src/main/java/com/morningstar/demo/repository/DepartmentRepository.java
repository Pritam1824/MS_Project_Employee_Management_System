package com.morningstar.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.morningstar.demo.entity.Department;
import com.morningstar.demo.entity.Employee;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Integer> {

	@Query(value="select * from employee where department_dept_id=:deptId",nativeQuery=true)
	List<Employee> getEmployeeByDeptId(@Param("deptId") int deptId);

//	@Query(value="select * from employee where email=:email and password=:password",nativeQuery=true)
//	Employee getEmployee(@Param("email") String email,@Param("password") String password);
	
}
