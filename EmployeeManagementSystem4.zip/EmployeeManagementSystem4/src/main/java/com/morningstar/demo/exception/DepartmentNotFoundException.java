package com.morningstar.demo.exception;

@SuppressWarnings("serial")
public class DepartmentNotFoundException extends RuntimeException {
	public DepartmentNotFoundException(String msg){
		super(msg);
	}

	public DepartmentNotFoundException() {
		// TODO Auto-generated constructor stub
	}
}
