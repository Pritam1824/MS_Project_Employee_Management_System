package com.morningstar.demo.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class GlobalExceptionHandler {
    @Value(value = "${data.exception.message1}")
    private String message1;
    @Value(value = "${data.exception.message2}")
    private String message2;
    @Value(value = "${data.exception.message3}")
    private String message3;
    @Value(value = "${data.exception.message4}")
    private String message4;
    
    
    @ExceptionHandler(value = EmployeeNotFoundException.class)
    public ResponseEntity<String> HandleEmployeeNotFoundException(EmployeeNotFoundException employeeNotFoundException) {
        return new ResponseEntity<String>(message1, HttpStatus.NOT_FOUND);
    }
   @ExceptionHandler(value = DepartmentNotFoundException.class)
    public ResponseEntity<String> HandleDepartmentNotFoundException(DepartmentNotFoundException departmentNotFoundException) {
        return new ResponseEntity<String>(message2, HttpStatus.NOT_FOUND);
    }
   
   @ExceptionHandler(value = InvalidCredentialsException.class)
   public ResponseEntity<String> HandleInvalidCredentialsException(InvalidCredentialsException invalidCredentialsException) {
       return new ResponseEntity<String>(message3, HttpStatus.NOT_FOUND);
   }
   
  
   
   @ExceptionHandler(value = Exception.class)
   public ResponseEntity<String> HandleException(Exception exception) {
       return new ResponseEntity<String>(message4, HttpStatus.NOT_FOUND);
   }
   
   
   
}