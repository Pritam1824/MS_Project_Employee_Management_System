package com.morningstar.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.morningstar.demo.entity.Employee;


@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	

	@Query(value="select * from employee where email=:email and password=:password",nativeQuery=true)
	Employee getEmployee(@Param("email") String email,@Param("password") String password);
	
//	@Query(value = "SELECT * FROM employee e WHERE e.email =?1 and e.password =?2",nativeQuery = true)
//	Employee getEmployee(String email,String password);
//
//	@Query(value="select * from users where U_Email=:username and U_Password=:password",nativeQuery=true)
//	User findUser(@Param("username")String username,@Param("password")String password);

}
