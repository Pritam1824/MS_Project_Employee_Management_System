package com.morningstar.demo.service;

import java.util.List;

import com.morningstar.demo.DTO.EmployeeDTO;
import com.morningstar.demo.entity.Employee;
import com.morningstar.demo.exception.EmployeeNotFoundException;
import com.morningstar.demo.exception.InvalidCredentialsException;

public interface EmployeeService {

	Employee addEmployee(EmployeeDTO employeeDTO);

	List<Employee> findAll();

	String deleteEmployeeById(int id)throws EmployeeNotFoundException ;

	void updateEmployee(Employee employee, int id) throws EmployeeNotFoundException;

	Employee displayEmployee(int id)throws EmployeeNotFoundException;

	String getEmployee(String email, String password)throws InvalidCredentialsException;

}
