package com.morningstar.demo.service;

import java.util.List;

import com.morningstar.demo.entity.Department;
import com.morningstar.demo.entity.Employee;
import com.morningstar.demo.exception.DepartmentNotFoundException;

public interface DepartmentService {

	public String addDepartment(Department department);

	public List<Department> findAll();

	public Department getDepartment(int id)throws DepartmentNotFoundException;

	public List<Employee> getEmployeeByDeptId(int deptId);

	

}
