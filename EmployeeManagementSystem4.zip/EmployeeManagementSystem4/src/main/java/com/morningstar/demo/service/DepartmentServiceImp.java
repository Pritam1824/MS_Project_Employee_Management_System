package com.morningstar.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.morningstar.demo.entity.Department;
import com.morningstar.demo.entity.Employee;
import com.morningstar.demo.exception.DepartmentNotFoundException;
import com.morningstar.demo.repository.DepartmentRepository;


@Service
public class DepartmentServiceImp implements DepartmentService {
	
	@Autowired
	private DepartmentRepository departmentRepository;
	
	@Override
	public String addDepartment(Department department) {
		departmentRepository.save(department);
		return "Department Added";
	}

	@Override
	public List<Department> findAll() {
		return departmentRepository.findAll();
	}

	@Override
	public Department getDepartment(int id)throws DepartmentNotFoundException {
		Department department;
        if (departmentRepository.findById(id).isEmpty()) {
            throw new DepartmentNotFoundException();
        } else {
        	 department = departmentRepository.findById(id).get();
        }
        return department;
	}

	@Override
	public List<Employee> getEmployeeByDeptId(int deptId) {
		
		List<Employee> emps = departmentRepository.getEmployeeByDeptId(deptId);
		
		return null;
	}

	

}
