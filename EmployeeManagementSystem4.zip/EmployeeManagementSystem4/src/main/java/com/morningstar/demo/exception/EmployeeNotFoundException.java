package com.morningstar.demo.exception;

@SuppressWarnings("serial")
public class EmployeeNotFoundException extends RuntimeException {
	public EmployeeNotFoundException(String msg){
		super(msg);
	}

	public EmployeeNotFoundException() {
		// TODO Auto-generated constructor stub
	}
}
